# Penetration Testing Study Notes

This repo contains all my penetration testing study notes, penetration testing tools, scripts, techniques, tricks and also many scripts that I found them useful from all over the internet.

## Resources/Credit:

To be honest I do not remember most of the resources for this repo, some notes are mine, others are just copied from forums, reddit, github repos.

Most of the credit for this work goes to those **awesome** people

- [adon90](https://github.com/adon90/pentest_compilation)
- [dostoevskylabs](https://github.com/dostoevskylabs/dostoevsky-pentest-notes)
- 

